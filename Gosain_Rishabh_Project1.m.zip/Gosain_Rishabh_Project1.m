sampleSizes = [1e2, 1e3, 1e4, 1e5]; % Sample size which 10^2, 10^3 and so on
disp(sampleSizes); %checking sample size

piEstimates = zeros(size(sampleSizes)); %this is the estimated value of pi
absoluteErrors = zeros(size(sampleSizes)); %absolute error from pi
runTimes = zeros(size(sampleSizes)); %this is runtime for each and every exp.

for i = 1:length(sampleSizes)
    numSamples = sampleSizes(i); %curr number of sample points

    tic; %timer to calculate runtime
    xVals = rand(numSamples,1); % generating random points 0 to 1               
    yVals = rand(numSamples,1); % generating random points 0 to 1              

    insideMask = (xVals.^2 + yVals.^2) <= 1; 
    % checking the points that are inside circle
    piEstimates(i) = 4 * mean(insideMask);
    runTimes(i) = toc; %recorded time

    absoluteErrors(i) = abs(piEstimates(i) - pi);
end
% plotting 
figure();
% plotting estimated pi vs N
subplot(3,1,1);                    
semilogx(sampleSizes, piEstimates); 
hold on;
yline(pi,'--r','LineWidth',1.2);   
grid on;
ylabel('π estimate');
title('π vs N');
% plotting absolute error vs N
subplot(3,1,2);                    
loglog(sampleSizes, absoluteErrors); 
grid on;
ylabel('| π - π̂ |');
title('Absolute Error vs N');
% plotting runtime vs N
subplot(3,1,3);          
semilogx(sampleSizes, runTimes);
grid on;
xlabel('N');
ylabel('Time (s)');
title('Runtime vs N');

%Task-2

sigFigs = 3;% significant figures
streakMax = 10;% Stability condition: for streakMax iterations, the same rounded result is needed.                
batchSize = 1000; %Number of random points that are generating in each loop

totalPoints = 0; % Total number of points     
insidePoints = 0; % points that are inside the circle
streakCount = 0; %
lastRounded = NaN;% last value of pi rounded
iterationCount = 0; %batches have been generated

tStart = tic; % timer
while streakCount < streakMax
% generating random points batch
    xVals = rand(batchSize,1);
    yVals = rand(batchSize,1);
% counting how many points are insdie cicle
    insidePoints = insidePoints + sum((xVals.^2 + yVals.^2) <= 1);
    totalPoints  = totalPoints + batchSize;
    iterationCount = iterationCount + 1;
% pi estimation for current pi value
    piEstimate = 4 * (insidePoints / totalPoints);
% pi estimaton for rounded pi value
    piRounded = round(piEstimate, sigFigs, 'significant');
% cehcking for pi value stable
    if isequal(piRounded, lastRounded)
        streakCount = streakCount + 1;
    else
        streakCount = 1;
        lastRounded = piRounded;
    end
end
% displaying the results
elapsedTime = toc(tStart);
fprintf('  Final estimate (rounded)   : %.10f\n', lastRounded);
fprintf('  Final estimate (raw)       : %.10f\n', piEstimate);
fprintf('  Total points used (N)      : %d\n', totalPoints);
fprintf('  Batches / iterations       : %d\n', iterationCount);


% Task-3

function piEstimate = mc_pi_task3(sigFigs, streakMax, batchSize, refreshEvery)
% Handling default values of input
    if nargin < 2 || isempty(streakMax),    streakMax = 10;    end
    if nargin < 3 || isempty(batchSize),    batchSize = 1000;  end
    if nargin < 4 || isempty(refreshEvery), refreshEvery = 2000; end

    totalPoints = 0; 
    insidePoints = 0; 
    streakCount = 0; 
    lastRounded = NaN; 
    sinceRefresh = 0;

    figHandle = figure('Name','Monte Carlo \pi (Task 3)');
    clf(figHandle); hold on; axis equal; xlim([0 1]); ylim([0 1]); box on
    xlabel('x'); ylabel('y');
    title('Estimating \pi — generating points...');

    % quarter circle boundaies
    theta = linspace(0, pi/2, 200);
    circleBoundary = plot(cos(theta), sin(theta), 'k-', 'LineWidth', 1.1);

    % scatter layers
    scatterInside  = scatter([], [], 8, 'b', 'filled', 'MarkerFaceAlpha',0.6, ...
                             'MarkerEdgeColor','none', 'DisplayName','inside');
    scatterOutside = scatter([], [], 8, 'r', 'filled', 'MarkerFaceAlpha',0.6, ...
                             'MarkerEdgeColor','none', 'DisplayName','outside');
    legend([circleBoundary, scatterInside, scatterOutside], ...
           {'quarter circle','inside','outside'}, 'Location','southoutside');

    tic; % timer
    while streakCount < streakMax
        % generating random values of batchSize
        xVals = rand(batchSize,1);
        yVals = rand(batchSize,1);
        isInside = (xVals.^2 + yVals.^2) <= 1;
% updation statment
        totalPoints  = totalPoints + batchSize;
        insidePoints = insidePoints + sum(isInside);
% estimating value of pi
        piEstimate = 4 * (insidePoints / totalPoints);
        piRounded  = round(piEstimate, sigFigs, 'significant');

        if isequal(piRounded, lastRounded)
            streakCount = streakCount + 1;
        else
            streakCount = 1;
            lastRounded = piRounded;
        end

        %plotting
        keepLimit = 5000;
        if numel(scatterInside.XData) > keepLimit
            idx = randperm(numel(scatterInside.XData), keepLimit);
            scatterInside.XData = scatterInside.XData(idx); 
            scatterInside.YData = scatterInside.YData(idx);
        end
        
        if numel(scatterOutside.XData) > keepLimit
            idx = randperm(numel(scatterOutside.XData), keepLimit);
            scatterOutside.XData = scatterOutside.XData(idx); 
            scatterOutside.YData = scatterOutside.YData(idx);
        end

        % appending new batch
        scatterInside.XData  = [scatterInside.XData(:);  xVals(isInside)];
        scatterInside.YData  = [scatterInside.YData(:);  yVals(isInside)];
        scatterOutside.XData = [scatterOutside.XData(:); xVals(~isInside)];
        scatterOutside.YData = [scatterOutside.YData(:); yVals(~isInside)];
% refreshing
        sinceRefresh = sinceRefresh + batchSize;
        if sinceRefresh >= refreshEvery
            title(sprintf('\\pi \\approx %.*g   (N = %d)', sigFigs, piRounded, totalPoints));
            drawnow limitrate
            sinceRefresh = 0;
        end
    end
    elapsedTime = toc;



    fprintf('\nTask 3 results:\n')
    fprintf('  Final estimate (rounded)   : %.*g\n', sigFigs, piRounded);
    fprintf('  Final estimate (raw)       : %.10f\n', piEstimate);
    fprintf('  Total points used (N)      : %d\n', totalPoints);
    
end

piValue = mc_pi_task3(3);% calling the function 

